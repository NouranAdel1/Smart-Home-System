/*
 * ADC_Interface.h
 *
 *  Created on: Aug 3, 2024
 *      Author: walee
 */

#ifndef MCAL_ADC_DRIVER_ADC_INTERFACE_H_
#define MCAL_ADC_DRIVER_ADC_INTERFACE_H_



#endif /* MCAL_ADC_DRIVER_ADC_INTERFACE_H_ */
